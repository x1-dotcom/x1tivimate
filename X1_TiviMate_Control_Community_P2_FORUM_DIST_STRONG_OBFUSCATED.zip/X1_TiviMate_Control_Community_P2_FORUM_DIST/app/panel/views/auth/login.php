<?php
/** @var string $panelName */
use X1\Core\Services\I18n\LocaleService;
$x1Locale = LocaleService::detect();
$host = parse_url((string)config('app.url', ''), PHP_URL_HOST) ?: ($_SERVER['HTTP_HOST'] ?? 'localhost');
$telegram = (string)config('community.telegram_url', 'https://t.me/+XkuQS_QuD6g4Nzc0');
$forum = (string)config('community.forum_url', 'https://forum.x1panel.space');
$discord = (string)config('community.discord_url', 'https://discord.gg/vSSw6jHmw');
$commercial = (string)config('community.commercial_url', $forum);
$company = (string)config('community.company_name', 'X1Tech Solutions SA');
?>
<!doctype html>
<html lang="<?=e($x1Locale)?>" data-bs-theme="dark" data-x1-locale="<?=e($x1Locale)?>">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Sign in — <?=e($panelName ?? 'X1 TiviMate Control')?></title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
<link rel="stylesheet" href="<?=url('/assets/css/x1.css')?>?v=<?=@filemtime(__DIR__.'/../../../public/assets/css/x1.css') ?: 1?>">
<link rel="icon" type="image/png" href="<?=url('/assets/img/x1-icon.png')?>">
</head>
<body class="x1-login-v2 x1-community-login-v3">
<?php include __DIR__.'/../partials/_language_switcher.php'; ?>
<main class="x1-login-shell x1-community-login-shell">
  <section class="x1-login-brand x1-community-brand-pane" aria-label="X1 Community">
    <div class="x1-login-brand-bg"></div>
    <div class="x1-login-brand-inner">
      <div class="x1-community-brand-visual">
        <img class="x1-community-brand-image" src="<?=url('/assets/img/x1-community-brand.jpg')?>" alt="X1">
        <span class="x1-community-edition-badge"><i class="bi bi-stars"></i> Community Edition</span>
      </div>
      <h1 class="x1-login-brand-title">X1 TiviMate Control</h1>
      <p class="x1-login-brand-sub">A focused, free control panel for the supported TiviMate build — made to be useful, not deliberately crippled.</p>

      <ul class="x1-login-features x1-community-feature-list">
        <li><i class="bi bi-tv"></i><span><strong>Devices & pairing</strong><br>See installations, QR pairing and runtime state in one place.</span></li>
        <li><i class="bi bi-broadcast-pin"></i><span><strong>Portals & messages</strong><br>Manage portal endpoints and broadcast messages from the panel.</span></li>
        <li><i class="bi bi-shield-check"></i><span><strong>X1 Agent ready</strong><br>Secure enrollment, heartbeat and capability-aware remote control.</span></li>
      </ul>

      <aside class="x1-community-promo" aria-label="X1 Control Center promotion">
        <div class="x1-community-promo-top">
          <span class="x1-community-promo-kicker">Need more than one TiviMate panel?</span>
          <span class="x1-community-promo-tag">PRO</span>
        </div>
        <h2>X1 Control Center</h2>
        <p>Professional fleet operations with resellers, clients, staged OTA, approvals, NOC, SLA, automation and multi-app control.</p>
        <a class="x1-community-promo-cta" href="<?=e($commercial)?>" target="_blank" rel="noopener noreferrer">
          Discover the commercial platform <i class="bi bi-arrow-up-right"></i>
        </a>
      </aside>

      <nav class="x1-community-socials" aria-label="X1 community links">
        <a href="<?=e($telegram)?>" target="_blank" rel="noopener noreferrer"><i class="bi bi-telegram"></i><span>Telegram</span></a>
        <a href="<?=e($forum)?>" target="_blank" rel="noopener noreferrer"><i class="bi bi-chat-square-text"></i><span>Forum</span></a>
        <a href="<?=e($discord)?>" target="_blank" rel="noopener noreferrer"><i class="bi bi-discord"></i><span>Discord</span></a>
      </nav>
    </div>
  </section>

  <section class="x1-login-form-side x1-community-login-form-side">
    <div class="x1-login-card-v2 x1-community-login-card">
      <header class="x1-login-card-head">
        <div class="x1-community-login-mark"><img src="<?=url('/assets/img/x1-icon.png')?>" alt="X1"></div>
        <div>
          <span class="x1-community-form-eyebrow">X1 TiviMate Control</span>
          <h2 class="h4 mb-1">Welcome back</h2>
          <p class="text-secondary small mb-0">Sign in to manage your Community panel.</p>
        </div>
      </header>

      <?php if ($msg=flash('error')): ?><div class="alert alert-danger py-2 small"><?=e($msg)?></div><?php endif; ?>
      <?php if ($msg=flash('success')): ?><div class="alert alert-success py-2 small"><?=e($msg)?></div><?php endif; ?>

      <form method="post" action="<?=url('/login')?>" autocomplete="on">
        <?=csrf_field()?>
        <label class="form-label small text-secondary" for="x1-id">Email or username</label>
        <div class="x1-input-wrap mb-3">
          <i class="bi bi-person"></i>
          <input id="x1-id" class="form-control form-control-lg" name="identifier" autocomplete="username" required autofocus>
        </div>
        <label class="form-label small text-secondary" for="x1-pw">Password</label>
        <div class="x1-input-wrap mb-3">
          <i class="bi bi-lock"></i>
          <input id="x1-pw" class="form-control form-control-lg" type="password" name="password" autocomplete="current-password" required>
          <button class="x1-input-eye" type="button" data-x1-password-toggle aria-label="Show password"><i class="bi bi-eye"></i></button>
        </div>
        <?=\X1\Core\Services\Captcha::widgetHtml()?>
        <button class="btn btn-primary btn-lg w-100 x1-login-submit" type="submit"><i class="bi bi-box-arrow-in-right"></i> Sign in</button>
      </form>

      <div class="x1-login-card-foot"><i class="bi bi-shield-check"></i> CSRF protection · brute-force protection · optional TOTP 2FA</div>
    </div>

    <div class="x1-community-mini-links">
      <a href="<?=e($telegram)?>" target="_blank" rel="noopener noreferrer"><i class="bi bi-telegram"></i> Telegram</a>
      <span>·</span>
      <a href="<?=e($forum)?>" target="_blank" rel="noopener noreferrer">Forum</a>
      <span>·</span>
      <a href="<?=e($discord)?>" target="_blank" rel="noopener noreferrer">Discord</a>
    </div>
    <p class="x1-login-copy x1-community-copyright">Copyright © <?=date('Y')?> <?=e($company)?>. All Rights Reserved.<br><span><?=e((string)$host)?> · Community Edition</span></p>
  </section>
</main>
<script>
document.addEventListener('click',function(e){
  var b=e.target.closest('[data-x1-password-toggle]'); if(!b)return;
  var i=document.getElementById('x1-pw'); if(!i)return;
  var show=i.type==='password'; i.type=show?'text':'password';
  b.setAttribute('aria-label',show?'Hide password':'Show password');
  var icon=b.querySelector('i'); if(icon) icon.className=show?'bi bi-eye-slash':'bi bi-eye';
});
</script>
<script src="<?=url('/assets/i18n/x1-i18n.js')?>" defer></script>
</body></html>
