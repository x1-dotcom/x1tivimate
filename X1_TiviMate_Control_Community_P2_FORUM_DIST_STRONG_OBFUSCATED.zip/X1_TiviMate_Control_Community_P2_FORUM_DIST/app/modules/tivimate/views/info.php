<?php use X1\Core\View; $st=$stats??[]; $n=fn(string $k)=>(int)($st[$k]??0); View::extend('layouts.app'); View::section('content'); ?>
<div class="x1-xc">
  <div class="x1-xc-crumbs"><a href="<?=url('/dashboard')?>">Dashboard</a><span class="sep">›</span><span class="current">TiviMate</span></div>
  <div class="x1-xc-hero mb-3"><div class="x1-xc-avatar"><i class="bi bi-tv"></i></div><div class="x1-xc-hero-body"><h1 class="x1-xc-hero-title">X1 TiviMate Control</h1><div class="x1-xc-hero-subtitle">Community Edition · <code>ar.tvplayer.tv</code></div></div><a class="x1-btn x1-btn-primary x1-btn-sm" href="<?=url('/modules/tivimate/services')?>"><i class="bi bi-hdd-network"></i><span>Manage portals</span></a></div>
  <div class="x1-xc-grid">
    <?php foreach([['portals','bi-hdd-network','Portals'],['portals_enabled','bi-check-circle','Enabled'],['devices','bi-tv','Devices'],['messages','bi-megaphone','Messages']] as [$key,$icon,$label]): ?>
      <div class="x1-xc-card x1-xc-col-3"><div class="x1-xc-card-head"><i class="bi <?=e($icon)?>"></i><h2 class="x1-xc-card-title"><?=e($label)?></h2></div><div style="font-size:2rem;font-weight:800;line-height:1.1"><?=$n($key)?></div></div>
    <?php endforeach; ?>
  </div>
  <div class="x1-xc-grid" style="margin-top:1rem">
    <section class="x1-xc-card x1-xc-col-8"><div class="x1-xc-card-head"><i class="bi bi-command"></i><h2 class="x1-xc-card-title">Quick control</h2></div><div class="x1-btn-row"><a class="x1-btn x1-btn-ghost x1-btn-sm" href="<?=url('/modules/tivimate/services')?>"><i class="bi bi-hdd-network"></i><span>Portals</span></a><a class="x1-btn x1-btn-ghost x1-btn-sm" href="<?=url('/modules/tivimate/devices')?>"><i class="bi bi-tv"></i><span>Devices</span></a><a class="x1-btn x1-btn-ghost x1-btn-sm" href="<?=url('/modules/tivimate/messages')?>"><i class="bi bi-megaphone"></i><span>Messages</span></a><a class="x1-btn x1-btn-ghost x1-btn-sm" href="<?=url('/modules/tivimate/runtime')?>"><i class="bi bi-sliders"></i><span>Runtime</span></a></div></section>
    <section class="x1-xc-card x1-xc-col-4"><div class="x1-xc-card-head"><i class="bi bi-shield-check"></i><h2 class="x1-xc-card-title">Community Edition</h2></div><div class="small text-muted">Focused TiviMate control for a single operator: portals, device visibility, messages, runtime configuration and QR pairing.</div></section>
  </div>
</div>
<?php View::endSection(); ?>
