<?php /** @var string $secret */ /** @var string $uri */ /** @var bool $enabled */ ?>
<?php \X1\Core\View::extend('layouts.app'); ?>
<?php \X1\Core\View::section('content'); ?>
<div class="x1-card" style="max-width:620px">
  <h2 class="h5 mb-2">Two-Factor Authentication</h2>
  <?php if ($enabled): ?>
    <p class="text-success">2FA is currently <strong>enabled</strong>.</p>
    <form method="post" action="<?=url('/2fa/disable')?>"><?=csrf_field()?><button class="btn btn-outline-danger btn-sm">Disable 2FA</button></form>
  <?php else: ?>
    <p class="text-secondary small">The QR is generated locally. Your TOTP secret is not sent to an external QR service.</p>
    <div class="row g-3 align-items-center">
      <div class="col-md-5"><div id="x1-totp-qr" style="background:#fff;padding:12px;border-radius:12px;display:inline-block"></div></div>
      <div class="col-md-7"><label class="form-label small">Secret (manual entry)</label><input class="form-control" readonly value="<?=e($secret)?>"><form method="post" action="<?=url('/2fa/enable')?>" class="mt-3"><?=csrf_field()?><label class="form-label small">6-digit code</label><input class="form-control" name="code" inputmode="numeric" pattern="[0-9]{6}" maxlength="6" required><button class="btn btn-info w-100 mt-3">Enable 2FA</button></form></div>
    </div>
    <script src="<?=url('/assets/tivimate/qrcode-browser.js')?>"></script>
    <script>(function(){const text=<?=json_encode($uri,JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_UNESCAPED_SLASHES)?>;const q=new X1QRCode(-1,X1QRErrorCorrectLevel.M);q.addData(text);q.make();let h='<table style="border-collapse:collapse">';for(let r=0;r<q.getModuleCount();r++){h+='<tr>';for(let c=0;c<q.getModuleCount();c++)h+='<td style="width:5px;height:5px;padding:0;background:'+(q.isDark(r,c)?'#000':'#fff')+'"></td>';h+='</tr>';}h+='</table>';document.getElementById('x1-totp-qr').innerHTML=h;})();</script>
  <?php endif; ?>
</div>
<?php \X1\Core\View::endSection(); ?>
