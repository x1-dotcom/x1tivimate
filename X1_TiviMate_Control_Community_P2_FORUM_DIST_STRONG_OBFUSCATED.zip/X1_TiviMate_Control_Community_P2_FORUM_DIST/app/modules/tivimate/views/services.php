<?php
use X1\Core\View;
$rows=$services ?? [];
$action=url('/modules/tivimate/services');
View::extend('layouts.app'); View::section('content');
?>
<div class="x1-xc">
  <div class="x1-xc-crumbs"><a href="<?=url('/dashboard')?>">Dashboard</a><span class="sep">›</span><span class="current">TiviMate</span><span class="sep">›</span><span class="current">Portals</span></div>
  <div class="x1-xc-hero mb-3"><div class="x1-xc-avatar"><i class="bi bi-hdd-network"></i></div><div class="x1-xc-hero-body"><h1 class="x1-xc-hero-title">Portals</h1><div class="x1-xc-hero-subtitle">Login endpoints published to the supported TiviMate build. <code>ar.tvplayer.tv</code></div></div></div>

  <?php if($m=flash('error')): ?><div class="alert alert-danger"><?=e($m)?></div><?php endif; ?>
  <?php if($m=flash('success')): ?><div class="alert alert-success"><?=e($m)?></div><?php endif; ?>

  <section class="x1-xc-card mb-3">
    <div class="d-flex align-items-center justify-content-between gap-3 flex-wrap mb-3"><div><h2 class="h5 mb-1"><i class="bi bi-plus-circle text-info"></i> Add portal</h2><div class="small text-muted">Use the provider base URL. Credentials are entered during pairing/login, not stored here.</div></div><span class="badge text-bg-dark border"><?=count($rows)?> total</span></div>
    <form method="post" action="<?=e($action)?>" class="row g-3 align-items-end">
      <?=csrf_field()?><input type="hidden" name="_action" value="add">
      <div class="col-lg-3"><label class="form-label small">Name</label><input class="form-control" name="name" placeholder="Main Portal" maxlength="191" required></div>
      <div class="col-lg-2"><label class="form-label small">Type</label><select class="form-select" name="type"><option value="xtream">Xtream</option><option value="stalker">Stalker</option><option value="m3u8">M3U8</option></select></div>
      <div class="col-lg-5"><label class="form-label small">Base URL</label><input class="form-control" type="url" name="url" placeholder="https://provider.example:443" maxlength="500" required></div>
      <div class="col-lg-2"><button class="btn btn-primary w-100"><i class="bi bi-plus-lg"></i> Add</button></div>
    </form>
  </section>

  <section class="x1-xc-card">
    <div class="d-flex align-items-center justify-content-between mb-3"><div><h2 class="h5 mb-1">Published portals</h2><div class="small text-muted">Only enabled rows are returned to the APK.</div></div></div>
    <?php if(!$rows): ?><div class="alert alert-info mb-0">No portals yet. Add the first one above.</div>
    <?php else: ?><div class="table-responsive"><table class="table align-middle mb-0"><thead><tr><th style="width:70px">Order</th><th>Name</th><th>Type</th><th>URL</th><th>Status</th><th class="text-end">Actions</th></tr></thead><tbody>
    <?php foreach($rows as $r): $on=(int)$r['enabled']===1; ?><tr><td class="text-secondary">#<?=e($r['position'])?></td><td><strong><?=e($r['name'])?></strong></td><td><span class="badge bg-primary-subtle text-primary border border-primary-subtle"><?=e(strtoupper((string)$r['type']))?></span></td><td><code><?=e($r['url'])?></code></td><td><?=$on?'<span class="badge bg-success-subtle text-success border border-success-subtle">Enabled</span>':'<span class="badge bg-secondary-subtle text-secondary border border-secondary-subtle">Disabled</span>'?></td><td class="text-end"><form method="post" action="<?=e($action)?>" class="d-inline"><?=csrf_field()?><input type="hidden" name="_action" value="toggle"><input type="hidden" name="id" value="<?=(int)$r['id']?>"><button class="btn btn-outline-secondary btn-sm" title="Toggle"><i class="bi <?=$on?'bi-pause-circle':'bi-play-circle'?>"></i></button></form> <form method="post" action="<?=e($action)?>" class="d-inline" onsubmit="return confirm('Delete this portal?')"><?=csrf_field()?><input type="hidden" name="_action" value="delete"><input type="hidden" name="id" value="<?=(int)$r['id']?>"><button class="btn btn-outline-danger btn-sm"><i class="bi bi-trash"></i></button></form></td></tr><?php endforeach; ?>
    </tbody></table></div><?php endif; ?>
  </section>
</div>
<?php View::endSection(); ?>
