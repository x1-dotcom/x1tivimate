<?php use X1\Core\View; View::extend('layouts.app'); View::section('content'); ?>
<div class="x1-xc"><div class="x1-xc-hero mb-3"><div class="x1-xc-avatar"><i class="bi bi-tv"></i></div><div class="x1-xc-hero-body"><h1 class="x1-xc-hero-title">Devices</h1><div class="x1-xc-hero-subtitle">TiviMate installations that have contacted this panel.</div></div><span class="badge text-bg-secondary"><?=count($devices)?> tracked</span></div>
<div class="x1-xc-card"><div class="table-responsive"><table class="table table-dark table-hover align-middle mb-0"><thead><tr><th>Device</th><th>Model</th><th>App</th><th>Country</th><th>IP</th><th>Last seen</th><th>Status</th></tr></thead><tbody>
<?php if(!$devices):?><tr><td colspan="7" class="text-secondary">No devices yet.</td></tr><?php endif;?>
<?php foreach($devices as $d): $online=strtotime((string)$d['last_seen_at'])>=time()-300;?><tr><td><code><?=e((string)$d['device_id'])?></code></td><td><?=e((string)($d['model']??'—'))?></td><td><?=e((string)($d['app_version']??'—'))?></td><td><?=e((string)($d['country']??'—'))?></td><td><?=e((string)($d['last_ip']??'—'))?></td><td><?=e((string)$d['last_seen_at'])?></td><td><span class="badge <?=$online?'text-bg-success':'text-bg-secondary'?>"><?=$online?'ONLINE':'OFFLINE'?></span></td></tr><?php endforeach;?>
</tbody></table></div></div></div>
<?php View::endSection(); ?>
