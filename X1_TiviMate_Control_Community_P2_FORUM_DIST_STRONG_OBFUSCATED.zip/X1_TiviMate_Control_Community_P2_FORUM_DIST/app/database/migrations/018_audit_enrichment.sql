-- Enrich audit_log with geo + bot/device classification.
-- Filled lazily on insert; backfill via bin/x1_audit_enrich.php.

ALTER TABLE audit_log
  ADD COLUMN country_iso CHAR(2)     NULL AFTER user_agent,
  ADD COLUMN country_name VARCHAR(80) NULL AFTER country_iso,
  ADD COLUMN city         VARCHAR(120) NULL AFTER country_name,
  ADD COLUMN asn          VARCHAR(64)  NULL AFTER city,
  ADD COLUMN is_bot       TINYINT(1)   NOT NULL DEFAULT 0 AFTER asn,
  ADD COLUMN device_kind  VARCHAR(16)  NULL AFTER is_bot,
  ADD COLUMN browser      VARCHAR(64)  NULL AFTER device_kind,
  ADD INDEX idx_audit_country (country_iso),
  ADD INDEX idx_audit_isbot   (is_bot);

-- Cache for IP→geo lookups so we don't re-call ip-api every request.
-- TTL ~30 days enforced in IpIntel::lookup().
CREATE TABLE IF NOT EXISTS ip_intel (
    ip_address   VARCHAR(45) NOT NULL PRIMARY KEY,
    country_iso  CHAR(2)     NULL,
    country_name VARCHAR(80) NULL,
    city         VARCHAR(120) NULL,
    region       VARCHAR(80) NULL,
    asn          VARCHAR(64) NULL,
    isp          VARCHAR(120) NULL,
    is_proxy     TINYINT(1)  NOT NULL DEFAULT 0,
    is_hosting   TINYINT(1)  NOT NULL DEFAULT 0,
    looked_up_at DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY idx_ip_intel_country (country_iso),
    KEY idx_ip_intel_ts      (looked_up_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Same enrichment on login_attempts so brute-force triage shows where attempts come from.
ALTER TABLE login_attempts
  ADD COLUMN user_agent  VARCHAR(500) NULL AFTER ip_address,
  ADD COLUMN country_iso CHAR(2)      NULL AFTER user_agent,
  ADD COLUMN is_bot      TINYINT(1)   NOT NULL DEFAULT 0 AFTER country_iso;
