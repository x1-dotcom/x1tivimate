/* X1 Panel i18n runtime v10 — manual switch + memory + browser/geo-aware fallback. */
(function () {
  'use strict';

  const SUPPORTED = ['pt-PT', 'es-ES', 'en-US', 'fr-FR', 'de-DE'];
  const ALIASES = {
    'pt':'pt-PT','pt-pt':'pt-PT','pt_br':'pt-PT','pt-br':'pt-PT',
    'es':'es-ES','es-es':'es-ES','es_mx':'es-ES','es-mx':'es-ES','es-ar':'es-ES',
    'en':'en-US','en-us':'en-US','en_gb':'en-US','en-gb':'en-US','en-ca':'en-US',
    'fr':'fr-FR','fr-fr':'fr-FR','fr_be':'fr-FR','fr-be':'fr-FR','fr-ca':'fr-FR',
    'de':'de-DE','de-de':'de-DE','de_at':'de-DE','de-at':'de-DE','de-ch':'de-DE',
    'ge':'de-DE','ge-ge':'de-DE','ge_ge':'de-DE'
  };
  const COOKIE = 'x1_locale';
  const STORAGE = 'x1_locale';
  let activeLocale = null;
  let activeDict = null;
  let observer = null;
  let applying = false;

  function normalize(raw) {
    if (!raw) return null;
    const v = String(raw).trim().replace('_', '-');
    if (!v) return null;
    if (SUPPORTED.includes(v)) return v;
    return ALIASES[v.toLowerCase()] || null;
  }

  function cookieGet(name) {
    const parts = document.cookie ? document.cookie.split(';') : [];
    for (const p of parts) {
      const [k, ...rest] = p.trim().split('=');
      if (k === name) return decodeURIComponent(rest.join('='));
    }
    return null;
  }

  function remember(locale) {
    try { localStorage.setItem(STORAGE, locale); } catch (_) {}
    document.cookie = COOKIE + '=' + encodeURIComponent(locale) + '; Max-Age=31536000; Path=/; SameSite=Lax';
  }

  function fromBrowser() {
    const list = navigator.languages && navigator.languages.length ? navigator.languages : [navigator.language || ''];
    for (const item of list) {
      const n = normalize(item);
      if (n) return n;
    }
    return null;
  }

  function detect() {
    const q = new URLSearchParams(location.search).get('lang');
    const qn = normalize(q);
    if (qn) { remember(qn); return qn; }

    try {
      const ls = normalize(localStorage.getItem(STORAGE));
      if (ls) return ls;
    } catch (_) {}

    const ck = normalize(cookieGet(COOKIE));
    if (ck) return ck;

    const server = normalize(document.documentElement.getAttribute('data-x1-locale'));
    if (server) return server;

    return fromBrowser() || 'pt-PT';
  }

  function localeBaseUrl() {
    const script = document.currentScript || document.querySelector('script[src*="x1-i18n.js"]');
    if (script && script.src) return new URL('./locales/', script.src).toString();
    return '/assets/i18n/locales/';
  }

  async function loadDict(locale) {
    const base = localeBaseUrl();
    const res = await fetch(base + locale + '.json', { cache: 'no-cache' });
    if (!res.ok) throw new Error('Locale not found: ' + locale);
    return res.json();
  }

  function getKey(dict, path) {
    if (!dict || !path) return null;
    const keys = dict.keys || {};
    if (Object.prototype.hasOwnProperty.call(keys, path)) return keys[path];
    return path.split('.').reduce((acc, k) => acc && acc[k] !== undefined ? acc[k] : null, dict);
  }

  function normText(s) {
    return String(s || '').replace(/\s+/g, ' ').trim();
  }

  function translateTextNode(node, textMap) {
    const raw = node.nodeValue || '';
    const trimmed = normText(raw);
    if (!trimmed || !textMap || !Object.prototype.hasOwnProperty.call(textMap, trimmed)) return;
    const before = raw.match(/^\s*/)[0] || '';
    const after = raw.match(/\s*$/)[0] || '';
    node.nodeValue = before + textMap[trimmed] + after;
  }

  function walkText(root, textMap) {
    if (!textMap || !root) return;
    const skip = new Set(['SCRIPT', 'STYLE', 'TEXTAREA', 'INPUT', 'SELECT', 'OPTION', 'CODE', 'PRE']);
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode(node) {
        const p = node.parentElement;
        if (!p || skip.has(p.tagName)) return NodeFilter.FILTER_REJECT;
        if (p.closest('[data-i18n-skip]')) return NodeFilter.FILTER_REJECT;
        if (!normText(node.nodeValue)) return NodeFilter.FILTER_REJECT;
        return NodeFilter.FILTER_ACCEPT;
      }
    });
    const nodes = [];
    while (walker.nextNode()) nodes.push(walker.currentNode);
    nodes.forEach(n => translateTextNode(n, textMap));
  }

  function applyDict(dict, root) {
    if (!dict) return;
    applying = true;
    const scope = root || document;
    document.documentElement.lang = activeLocale || 'pt-PT';
    document.documentElement.setAttribute('data-x1-locale', activeLocale || 'pt-PT');

    scope.querySelectorAll('[data-i18n]').forEach(el => {
      const v = getKey(dict, el.getAttribute('data-i18n'));
      if (v != null) el.textContent = v;
    });
    scope.querySelectorAll('[data-i18n-placeholder]').forEach(el => {
      const v = getKey(dict, el.getAttribute('data-i18n-placeholder'));
      if (v != null) el.setAttribute('placeholder', v);
    });
    scope.querySelectorAll('[data-i18n-title]').forEach(el => {
      const v = getKey(dict, el.getAttribute('data-i18n-title'));
      if (v != null) el.setAttribute('title', v);
    });
    scope.querySelectorAll('[data-i18n-aria]').forEach(el => {
      const v = getKey(dict, el.getAttribute('data-i18n-aria'));
      if (v != null) el.setAttribute('aria-label', v);
    });

    walkText(scope === document ? document.body : scope, dict.text || {});

    document.querySelectorAll('[data-x1-locale-select]').forEach(sel => {
      if (sel.value !== activeLocale) sel.value = activeLocale;
    });
    applying = false;
    window.dispatchEvent(new CustomEvent('x1:i18n:ready', { detail: { locale: activeLocale } }));
  }

  async function setLocale(locale, opts) {
    const n = normalize(locale) || 'pt-PT';
    activeLocale = n;
    remember(n);
    try {
      activeDict = await loadDict(n);
    } catch (e) {
      console.warn('[x1-i18n] failed to load locale', n, e);
      if (n !== 'pt-PT') {
        activeLocale = 'pt-PT';
        activeDict = await loadDict('pt-PT');
      }
    }
    applyDict(activeDict, document);
    if (!opts || opts.updateUrl !== false) {
      const url = new URL(location.href);
      url.searchParams.set('lang', activeLocale);
      history.replaceState({}, '', url.toString());
    }
  }

  function bindSwitcher() {
    document.addEventListener('change', function (e) {
      const sel = e.target.closest && e.target.closest('[data-x1-locale-select]');
      if (!sel || applying) return;
      setLocale(sel.value, { updateUrl: true });
    });
  }

  function observe() {
    if (observer || !document.body) return;
    let timer = null;
    observer = new MutationObserver(function (mutations) {
      if (!activeDict || applying) return;
      clearTimeout(timer);
      timer = setTimeout(function () {
        for (const m of mutations) {
          for (const n of m.addedNodes) {
            if (n.nodeType === 1) applyDict(activeDict, n);
          }
        }
      }, 80);
    });
    observer.observe(document.body, { childList: true, subtree: true });
  }

  document.addEventListener('DOMContentLoaded', function () {
    bindSwitcher();
    setLocale(detect(), { updateUrl: false }).then(observe).catch(err => console.warn('[x1-i18n]', err));
  });

  window.X1I18n = { setLocale, detect, normalize, supported: SUPPORTED.slice() };
})();
