# X1 TiviMate Control — Community Edition

Free, focused control panel for the supported TiviMate-based APK (`ar.tvplayer.tv`).

## Product boundary

Community is a real product, not a broken demo. It contains:

- TiviMate portal management;
- canonical device registry (MariaDB `devices`);
- welcome/runtime configuration;
- announcements/messages;
- basic QR pairing;
- compatibility API for the supplied APK;
- local TOTP QR generation;
- audit logging and secure panel login.

It deliberately does **not** contain the commercial X1 Control Center features: multi-reseller operations, SaaS licensing, advanced fleet automation, Release Vault/staged OTA, NOC/SLA/incidents, approvals, signed recovery, build provenance or production attestations.

## Install

Requirements: PHP 8.2+, MariaDB 10.6+/MySQL 8, nginx, PDO MySQL, OpenSSL, zlib, mbstring, JSON.

```bash
cp .env.example .env
# Set APP_URL and DB credentials. Generate a unique APP_KEY, for example:
#   php -r 'echo base64_encode(random_bytes(32)), PHP_EOL;'
# Never reuse an APP_KEY from another X1 installation.
php bin/migrate.php
php bin/create-admin.php --email=you@example.com --username=admin --password='use-a-long-password'
```

Point nginx at `public/` (example: `nginx.community.example.conf`).

## APK compatibility paths

Canonical:

- `/api/tivimate/api.php`
- `/api/tivimate/dns.php`
- `/api/tivimate/vpns.php`
- `/api/tivimate/sports.php`
- `/api/tivimate/streaming.php`
- `/api/tivimate/webview.php`
- `/api/tivimate/welcome.php`
- `/api/tivimate/qr/*`

Compatibility aliases are mounted under:

- `/api/reseller/tivimate/` — clean X1 compatibility base;
- `/Gizmos_RC11/api/reseller/tivimate/` — retained only for the supplied APK's hard-coded legacy base.

The legacy path is a binary-compatibility detail. The visible product name is X1.

## Security boundary

The release must never contain `.env`, JKS/keystore files, passwords, private PEM/key files, runtime databases, uploaded APKs or operational secrets. Run the included release verifier before publishing.

The public forum build uses protected runtime packing as anti-copy/rebrand friction. It is still not treated as a security boundary: secrets must never be shipped in the package.

## Public forum build

Publish only the protected `FORUM DIST`, never the maintainer source tree. Internal pure-PHP files are packed as authenticated AES-256-GCM runtime payloads; presentation templates remain readable because they are delivered to the browser anyway. Run `php tools/verify-protected-release.php app` before publication.

## Phase 2 — X1 ecosystem login + Device Agent

The Community login now uses the official X1 visual supplied by X1Tech Solutions SA, provides direct links to the X1 Telegram, forum and Discord, and includes a discreet upgrade card for X1 Control Center Commercial. Copyright uses the current year at runtime (`date('Y')`).

Device Agent v2 adds one-time enrollment, HMAC-signed heartbeat, capability reporting and a strict Community-safe command subset (`sync_config`, `show_message`, `check_update`). See `docs/DEVICE_AGENT_CONTRACT.md`.
