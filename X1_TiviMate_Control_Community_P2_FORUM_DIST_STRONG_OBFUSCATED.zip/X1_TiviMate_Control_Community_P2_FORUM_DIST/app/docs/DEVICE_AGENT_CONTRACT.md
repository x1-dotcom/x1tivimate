# X1 TiviMate Control Community — Device Agent v2

Community intentionally exposes only three safe capabilities:

- `sync_config`
- `show_message`
- `check_update`

Unknown capabilities are ignored server-side. Destructive fleet operations, unattended installation, staged OTA, NOC and advanced automation belong to X1 Control Center Commercial.

## Enrollment

`POST /api/x1/v2/enroll`

```json
{
  "enrollment_code": "x1e_...",
  "device_id": "stable-device-id",
  "app_version": "5.3.3-x1",
  "model": "Living Room TV",
  "capabilities": ["sync_config", "show_message", "check_update"]
}
```

The one-time code is stored only as SHA-256. The returned `device_token` is shown to the device exactly once and the server stores only SHA-256 of that token.

## Signed requests

Every authenticated Agent request sends:

```text
Authorization: Bearer <device_token>
X-X1-Timestamp: <unix seconds>
X-X1-Nonce: <16-96 chars [A-Za-z0-9_-]>
X-X1-Signature: <64 lowercase/uppercase hex chars accepted>
```

Canonical HMAC input:

```text
METHOD
PATH
TIMESTAMP
NONCE
SHA256_BODY
```

- HMAC: SHA-256
- key: plaintext `device_token` held only by the device
- `PATH`: request path without query string
- `SHA256_BODY`: SHA-256 of exact request-body bytes
- clock window: ±300 seconds
- nonce: unique per token; replay returns HTTP 409

## Endpoints

- `POST /api/x1/v2/heartbeat`
- `GET /api/x1/v2/commands`
- `POST /api/x1/v2/command-ack`
- `POST /api/x1/v2/command-result`

Heartbeat telemetry is normalized and allowlisted before persistence.
