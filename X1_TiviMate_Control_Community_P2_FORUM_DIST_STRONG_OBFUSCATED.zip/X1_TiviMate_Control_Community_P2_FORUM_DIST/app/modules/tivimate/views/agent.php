<?php use X1\Core\View; View::extend('layouts.app'); View::section('content');
$agentCode=flash('agent_code');
?>
<div class="x1-xc x1-agent-page">
  <div class="x1-xc-hero mb-3">
    <div class="x1-xc-avatar"><i class="bi bi-broadcast-pin"></i></div>
    <div class="x1-xc-hero-body"><h1 class="x1-xc-hero-title">X1 Device Agent</h1><div class="x1-xc-hero-subtitle">Secure enrollment, signed heartbeat and capability-aware Community remote control.</div></div>
    <span class="badge text-bg-info">SAFE CAPABILITIES ONLY</span>
  </div>

  <?php if($agentCode):?>
  <div class="x1-agent-secret mb-3">
    <div><span class="x1-agent-label">ONE-TIME ENROLLMENT CODE</span><code id="x1-agent-code"><?=e($agentCode)?></code><small>Expires in 15 minutes. The plaintext code is not stored in the database.</small></div>
    <button class="btn btn-outline-info" type="button" onclick="navigator.clipboard&&navigator.clipboard.writeText(document.getElementById('x1-agent-code').textContent)"><i class="bi bi-copy"></i> Copy</button>
  </div>
  <?php endif;?>

  <div class="row g-3 mb-3">
    <div class="col-xl-4">
      <section class="x1-xc-card h-100 p-3">
        <div class="d-flex align-items-center justify-content-between mb-3"><div><div class="x1-agent-label">ENROLL A TV</div><h2 class="h6 mb-0">Prepare enrollment</h2></div><i class="bi bi-qr-code text-info fs-4"></i></div>
        <form method="post" action="<?=url('/modules/tivimate/agent')?>"><?=csrf_field()?>
          <input type="hidden" name="action" value="create_enrollment">
          <label class="form-label small text-secondary">Expected Device ID <span class="text-secondary">(optional)</span></label>
          <input class="form-control mb-2" name="expected_device_id" maxlength="128" placeholder="Leave empty for any device">
          <p class="small text-secondary mb-3">Tie the code to a known device when possible. The code is single-use and stored only as SHA-256.</p>
          <button class="btn btn-info w-100 fw-semibold" type="submit"><i class="bi bi-key"></i> Create enrollment code</button>
        </form>
      </section>
    </div>
    <div class="col-xl-8">
      <section class="x1-xc-card h-100 p-3">
        <div class="x1-agent-label">COMMUNITY COMMAND POLICY</div>
        <h2 class="h6">Only three remote actions are enabled</h2>
        <div class="x1-agent-cap-grid">
          <div><i class="bi bi-arrow-repeat"></i><strong>Sync config</strong><span>Ask the supported build to refresh panel configuration.</span></div>
          <div><i class="bi bi-chat-left-text"></i><strong>Show message</strong><span>Display an operator message through the Agent bridge.</span></div>
          <div><i class="bi bi-cloud-arrow-down"></i><strong>Check update</strong><span>Open/check the updater path already present in the app.</span></div>
        </div>
        <p class="small text-secondary mt-3 mb-0">Restart, unattended install, bulk fleet automation and advanced OTA remain Commercial features. Unknown capabilities are ignored server-side.</p>
      </section>
    </div>
  </div>

  <section class="x1-xc-card mb-3">
    <div class="p-3 border-bottom border-secondary-subtle d-flex align-items-center justify-content-between"><div><div class="x1-agent-label">AGENT FLEET</div><h2 class="h6 mb-0">Enrolled / reporting devices</h2></div><span class="badge text-bg-secondary"><?=count($devices)?> devices</span></div>
    <div class="table-responsive"><table class="table table-dark table-hover align-middle mb-0"><thead><tr><th>Device</th><th>Agent</th><th>Capabilities</th><th>App</th><th>Last heartbeat</th><th>Remote control</th></tr></thead><tbody>
    <?php if(!$devices):?><tr><td colspan="6" class="text-secondary p-4">No devices have reported yet.</td></tr><?php endif;?>
    <?php foreach($devices as $d): $caps=array_values(array_filter(explode(',',(string)($d['capabilities']??'')))); $agentOnline=!empty($d['agent_last_seen'])&&strtotime((string)$d['agent_last_seen'])>=time()-180; ?>
      <tr>
        <td><code><?=e((string)$d['device_id'])?></code><div class="small text-secondary"><?=e((string)($d['model']?:'Unknown model'))?></div></td>
        <td><?php if((int)($d['active_tokens']??0)>0):?><span class="badge <?=$agentOnline?'text-bg-success':'text-bg-secondary'?>"><?=$agentOnline?'ONLINE':'ENROLLED'?></span><?php else:?><span class="badge text-bg-dark border">LEGACY ONLY</span><?php endif;?></td>
        <td><div class="d-flex flex-wrap gap-1"><?php foreach($caps as $c):?><span class="x1-agent-cap"><?=e($c)?></span><?php endforeach;?><?php if(!$caps):?><span class="text-secondary small">—</span><?php endif;?></div></td>
        <td><?=e((string)($d['app_version']?:'—'))?></td>
        <td><?=e((string)($d['agent_last_seen']?:'—'))?></td>
        <td>
          <?php if($caps):?><form method="post" action="<?=url('/modules/tivimate/agent')?>" class="x1-agent-command-form"><?=csrf_field()?><input type="hidden" name="action" value="queue_command"><input type="hidden" name="device_id" value="<?=e((string)$d['device_id'])?>"><select class="form-select form-select-sm" name="capability" onchange="this.form.querySelector('[data-msg]').hidden=this.value!=='show_message'">
          <?php foreach($caps as $c): if(!in_array($c,$safeCapabilities,true))continue;?><option value="<?=e($c)?>"><?=e(str_replace('_',' ',ucwords($c,'_')))?></option><?php endforeach;?></select><div data-msg hidden class="mt-2"><input class="form-control form-control-sm mb-1" name="message_title" placeholder="Title" maxlength="120"><textarea class="form-control form-control-sm" name="message_body" placeholder="Message" maxlength="1200" rows="2"></textarea></div><button class="btn btn-outline-info btn-sm mt-2" type="submit"><i class="bi bi-send"></i> Queue</button></form><?php endif;?>
          <?php if((int)($d['active_tokens']??0)>0):?><form method="post" action="<?=url('/modules/tivimate/agent')?>" class="mt-2"><?=csrf_field()?><input type="hidden" name="action" value="revoke_agent"><input type="hidden" name="device_id" value="<?=e((string)$d['device_id'])?>"><button class="btn btn-link btn-sm text-danger p-0" type="submit" onclick="return confirm('Revoke this Agent token?')">Revoke Agent</button></form><?php endif;?>
        </td>
      </tr>
    <?php endforeach;?>
    </tbody></table></div>
  </section>

  <div class="row g-3">
    <div class="col-xl-5"><section class="x1-xc-card h-100"><div class="p-3 border-bottom border-secondary-subtle"><div class="x1-agent-label">ENROLLMENT HISTORY</div><h2 class="h6 mb-0">Recent codes</h2></div><div class="table-responsive"><table class="table table-dark table-sm align-middle mb-0"><thead><tr><th>Expected</th><th>Created</th><th>Status</th></tr></thead><tbody><?php foreach($enrollments as $e): $expired=strtotime((string)$e['expires_at'])<time();?><tr><td><?=e((string)($e['expected_device_id']?:'Any device'))?></td><td><?=e((string)$e['created_at'])?></td><td><?php if($e['used_at']):?><span class="badge text-bg-success">USED</span><?php elseif($expired):?><span class="badge text-bg-secondary">EXPIRED</span><?php else:?><span class="badge text-bg-warning">READY</span><?php endif;?></td></tr><?php endforeach;?></tbody></table></div></section></div>
    <div class="col-xl-7"><section class="x1-xc-card h-100"><div class="p-3 border-bottom border-secondary-subtle"><div class="x1-agent-label">COMMAND LIFECYCLE</div><h2 class="h6 mb-0">Recent commands</h2></div><div class="table-responsive"><table class="table table-dark table-sm align-middle mb-0"><thead><tr><th>ID</th><th>Device</th><th>Command</th><th>State</th><th>Progress</th></tr></thead><tbody><?php foreach($commands as $c):?><tr><td>#<?=e((string)$c['id'])?></td><td><code><?=e((string)$c['target_device_id'])?></code></td><td><?=e((string)$c['command'])?></td><td><span class="badge text-bg-secondary"><?=e(strtoupper((string)$c['status']))?></span></td><td><?=e($c['progress']!==null?(string)$c['progress'].'%':'—')?></td></tr><?php endforeach;?></tbody></table></div></section></div>
  </div>
</div>
<?php View::endSection(); ?>
