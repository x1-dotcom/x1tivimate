<?php use X1\Core\View; View::extend('layouts.app'); View::section('content'); ?>
<div class="x1-xc">
  <div class="x1-xc-hero mb-3">
    <div class="x1-xc-avatar"><i class="bi bi-tv"></i></div>
    <div class="x1-xc-hero-body">
      <h1 class="x1-xc-hero-title">X1 TiviMate Control</h1>
      <div class="x1-xc-hero-subtitle">Community Edition · focused, lightweight TiviMate operations.</div>
    </div>
    <span class="badge text-bg-info">FREE COMMUNITY</span>
  </div>
  <div class="row g-3 mb-4">
    <?php foreach ([
      ['Devices',(int)$stats['devices_total'],'bi-tv'],
      ['Online',(int)$stats['devices_online'],'bi-broadcast-pin'],
      ['X1 Agents',(int)$stats['agents_enrolled'].' / '.(int)$stats['agents_online'],'bi-shield-check'],
      ['Portals',(int)$stats['portals_enabled'].' / '.(int)$stats['portals'],'bi-server'],
      ['Messages',(int)$stats['messages_active'],'bi-megaphone'],
      ['Open commands',(int)$stats['commands_open'],'bi-terminal']
    ] as [$label,$value,$icon]): ?>
      <div class="col-6 col-lg"><div class="x1-xc-card h-100"><div class="small text-secondary"><i class="bi <?=e($icon)?> me-1"></i><?=e($label)?></div><div class="display-6 fw-bold mt-2"><?=e((string)$value)?></div></div></div>
    <?php endforeach; ?>
  </div>

  <div class="row g-3 mb-4">
    <div class="col-xl-7"><div class="x1-xc-card h-100"><div class="x1-agent-label">X1 COMMUNITY</div><h2 class="h5 mb-2">Support, releases & discussion</h2><p class="text-secondary small">Follow Community releases, report compatibility issues and exchange deployment notes with other X1 users.</p><div class="d-flex flex-wrap gap-2"><a class="btn btn-sm btn-outline-info" href="<?=e((string)config('community.telegram_url','https://t.me/+XkuQS_QuD6g4Nzc0'))?>" target="_blank" rel="noopener noreferrer"><i class="bi bi-telegram"></i> Telegram</a><a class="btn btn-sm btn-outline-light" href="<?=e((string)config('community.forum_url','https://forum.x1panel.space'))?>" target="_blank" rel="noopener noreferrer"><i class="bi bi-chat-square-text"></i> X1 Forum</a><a class="btn btn-sm btn-outline-light" href="<?=e((string)config('community.discord_url','https://discord.gg/vSSw6jHmw'))?>" target="_blank" rel="noopener noreferrer"><i class="bi bi-discord"></i> Discord</a></div></div></div>
    <div class="col-xl-5"><div class="x1-xc-card h-100 x1-community-dashboard-promo"><div class="x1-agent-label">PROFESSIONAL OPERATIONS</div><h2 class="h5 mb-2">X1 Control Center</h2><p class="text-secondary small">When you outgrow a single Community panel: multi-app fleet, resellers, clients, staged OTA, NOC, SLA and automation.</p><a class="btn btn-sm btn-info fw-semibold" href="<?=e((string)config('community.commercial_url','https://forum.x1panel.space'))?>" target="_blank" rel="noopener noreferrer">Discover Commercial <i class="bi bi-arrow-up-right"></i></a></div></div>
  </div>
  <div class="x1-xc-card">
    <div class="d-flex align-items-center justify-content-between mb-3"><div><h2 class="h5 mb-1">Recent devices</h2><div class="small text-secondary">Devices seen by the X1 TiviMate API.</div></div><a class="btn btn-sm btn-outline-info" href="<?=url('/modules/tivimate/devices')?>">Open devices</a></div>
    <div class="table-responsive"><table class="table table-dark table-hover align-middle mb-0"><thead><tr><th>Device</th><th>Model</th><th>Version</th><th>IP</th><th>Last seen</th></tr></thead><tbody>
      <?php if (!$recent): ?><tr><td colspan="5" class="text-secondary">No TiviMate devices have checked in yet.</td></tr><?php endif; ?>
      <?php foreach($recent as $d): ?><tr><td><code><?=e((string)$d['device_id'])?></code></td><td><?=e((string)($d['model']??'—'))?></td><td><?=e((string)($d['app_version']??'—'))?></td><td><?=e((string)($d['last_ip']??'—'))?></td><td><?=e((string)$d['last_seen_at'])?></td></tr><?php endforeach; ?>
    </tbody></table></div>
  </div>
</div>
<?php View::endSection(); ?>
