<?php
declare(strict_types=1);
if(!function_exists('_x1bc86f79a')){require __DIR__ . '/../core/.x1rt.php';}
$__x1f_5b294c=__FILE__;
return eval(_x1bc86f79a('knDfahCrWKkhdGhgvzy6JFoj3XscN8sants0MhIeGmvb9bFMi1nJf5KFyyLWEXNVPAOHsIK1a2J5HsXIV0o6y/roya0/6ciAedrSAEVV6xTA6By7kJbqnM3WeS8nZrl7AUGLXr6I91LgIDwhKW2xHPlW/y9ldIk+3lRYGhdJOoM=','uSGMyrZSlvFEA4If','jKkggcNuML0zqMhrNqU0Qw=='));
