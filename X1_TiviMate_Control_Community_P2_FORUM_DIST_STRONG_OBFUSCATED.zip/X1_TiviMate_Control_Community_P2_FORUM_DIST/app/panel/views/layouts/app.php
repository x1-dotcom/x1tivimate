<?php
/** @var array $modulesBySection */
use X1\Core\Edition;
use X1\Core\View;
$uri=parse_url($_SERVER['REQUEST_URI']??'/',PHP_URL_PATH)?:'/';
$active=fn(string $p): bool => $uri===$p || str_starts_with($uri,rtrim($p,'/').'/');
$u=user();
?>
<!doctype html><html lang="en" data-bs-theme="dark"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title><?=e($title??Edition::productName())?></title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"><link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css"><link rel="stylesheet" href="<?=url('/assets/css/x1.css')?>"></head>
<body class="x1-body"><nav class="x1-sidebar"><a class="x1-brand" href="<?=url('/dashboard')?>"><img class="x1-logo" src="<?=url('/assets/img/x1-icon.png')?>" alt="X1"><span class="x1-brand-wrap"><span class="x1-brand-text">X1 TiviMate Control</span><span class="x1-brand-sub">Community Edition</span></span></a><ul class="x1-nav">
<li<?=$active('/dashboard')?' class="is-active"':''?>><a class="x1-nav-link" href="<?=url('/dashboard')?>"><i class="bi bi-speedometer2"></i><span class="x1-nav-label">Overview</span></a></li>
<?php foreach(($modulesBySection??[]) as $mods): foreach($mods as $m): if($m->id!=='tivimate')continue; foreach($m->pages() as $p): if(isset($p['enabled'])&&!$p['enabled'])continue; $path='/modules/'.$m->id.'/'.$p['slug']; ?>
<li<?=$active($path)?' class="is-active"':''?>><a class="x1-nav-link" href="<?=url($path)?>"><i class="bi bi-<?=e((string)($p['icon']??'circle'))?>"></i><span class="x1-nav-label"><?=e((string)($p['title']??$p['slug']))?></span></a></li>
<?php endforeach; endforeach; endforeach; ?>
<li class="x1-section">Security</li><li<?=$active('/2fa/setup')?' class="is-active"':''?>><a class="x1-nav-link" href="<?=url('/2fa/setup')?>"><i class="bi bi-shield-lock"></i><span class="x1-nav-label">Two-factor auth</span></a></li>
</ul><?php if($u):?><div class="x1-side-foot"><div class="small text-secondary mb-2"><?=e((string)($u['display_name']??$u['username']))?></div><form method="post" action="<?=url('/logout')?>"><?=csrf_field()?><button class="x1-logout-btn" type="submit"><i class="bi bi-box-arrow-right"></i><span>Sign out</span></button></form></div><?php endif;?></nav>
<main class="x1-main"><header class="x1-topbar"><div><div class="text-info small fw-semibold">X1 · COMMUNITY</div><h1 class="h5 mb-0"><?=e($title??'Overview')?></h1></div><div class="d-flex align-items-center gap-2"><span class="badge text-bg-info">TIVIMATE ONLY</span></div></header>
<?php foreach(['error','success','info','warning'] as $lvl):$msg=flash($lvl);if($msg):?><div class="alert alert-<?=$lvl==='error'?'danger':$lvl?> mx-3 mt-3"><?=e($msg)?></div><?php endif;endforeach;?><div class="x1-content"><?=View::yield('content')?></div></main>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script></body></html>
