-- X1 Apps Central Panel - Core Schema
-- MariaDB 10.6+ / MySQL 8.0+
-- charset: utf8mb4, engine: InnoDB

SET NAMES utf8mb4;
SET time_zone = '+00:00';

-- ============================================================
-- USERS & AUTH
-- ============================================================
CREATE TABLE IF NOT EXISTS users (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    email VARCHAR(190) NOT NULL,
    username VARCHAR(64) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    display_name VARCHAR(190) NULL,
    avatar_url VARCHAR(500) NULL,
    role_id INT UNSIGNED NOT NULL DEFAULT 3,
    status ENUM('active','disabled','pending') NOT NULL DEFAULT 'active',
    twofa_secret VARCHAR(64) NULL,
    twofa_enabled TINYINT(1) NOT NULL DEFAULT 0,
    failed_logins INT UNSIGNED NOT NULL DEFAULT 0,
    locked_until DATETIME NULL,
    last_login_at DATETIME NULL,
    last_login_ip VARCHAR(45) NULL,
    locale VARCHAR(10) NOT NULL DEFAULT 'en',
    theme VARCHAR(20) NOT NULL DEFAULT 'dark',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_users_email (email),
    UNIQUE KEY uq_users_username (username),
    KEY idx_users_role (role_id),
    KEY idx_users_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS roles (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    slug VARCHAR(32) NOT NULL,
    name VARCHAR(64) NOT NULL,
    description VARCHAR(255) NULL,
    is_system TINYINT(1) NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_roles_slug (slug)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS permissions (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    slug VARCHAR(128) NOT NULL,
    module_id VARCHAR(64) NULL,
    description VARCHAR(255) NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_permissions_slug (slug),
    KEY idx_permissions_module (module_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS role_permissions (
    role_id INT UNSIGNED NOT NULL,
    permission_id INT UNSIGNED NOT NULL,
    PRIMARY KEY (role_id, permission_id),
    CONSTRAINT fk_rp_role FOREIGN KEY (role_id) REFERENCES roles(id) ON DELETE CASCADE,
    CONSTRAINT fk_rp_perm FOREIGN KEY (permission_id) REFERENCES permissions(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS sessions (
    id VARCHAR(128) NOT NULL,
    user_id BIGINT UNSIGNED NULL,
    ip_address VARCHAR(45) NULL,
    user_agent VARCHAR(500) NULL,
    fingerprint VARCHAR(128) NULL,
    payload MEDIUMTEXT NOT NULL,
    last_activity INT UNSIGNED NOT NULL,
    PRIMARY KEY (id),
    KEY idx_sessions_user (user_id),
    KEY idx_sessions_activity (last_activity)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS login_attempts (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    identifier VARCHAR(190) NOT NULL,
    ip_address VARCHAR(45) NOT NULL,
    success TINYINT(1) NOT NULL DEFAULT 0,
    attempted_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_login_ident (identifier),
    KEY idx_login_ip (ip_address),
    KEY idx_login_time (attempted_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- MODULES (one row per installed APK module)
-- ============================================================
CREATE TABLE IF NOT EXISTS modules (
    id VARCHAR(64) NOT NULL,
    name VARCHAR(128) NOT NULL,
    version VARCHAR(32) NOT NULL,
    section VARCHAR(64) NOT NULL DEFAULT 'OTT Applications',
    icon VARCHAR(500) NULL,
    manifest_json LONGTEXT NOT NULL,
    enabled TINYINT(1) NOT NULL DEFAULT 1,
    installed_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_modules_section (section),
    KEY idx_modules_enabled (enabled)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS module_versions (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    module_id VARCHAR(64) NOT NULL,
    version VARCHAR(32) NOT NULL,
    changelog TEXT NULL,
    package_path VARCHAR(500) NULL,
    published_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_mv_module_version (module_id, version),
    CONSTRAINT fk_mv_module FOREIGN KEY (module_id) REFERENCES modules(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS module_migrations (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    module_id VARCHAR(64) NOT NULL,
    migration VARCHAR(190) NOT NULL,
    applied_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_mm (module_id, migration)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS module_settings (
    module_id VARCHAR(64) NOT NULL,
    setting_key VARCHAR(128) NOT NULL,
    setting_value LONGTEXT NULL,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (module_id, setting_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- LICENSES
-- ============================================================
CREATE TABLE IF NOT EXISTS licenses (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    license_key VARCHAR(64) NOT NULL,
    module_id VARCHAR(64) NULL,              -- NULL = core panel license
    owner_email VARCHAR(190) NULL,
    owner_name VARCHAR(190) NULL,
    max_devices INT UNSIGNED NOT NULL DEFAULT 1,
    status ENUM('active','revoked','expired','trial') NOT NULL DEFAULT 'active',
    issued_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    expires_at DATETIME NULL,
    last_validated_at DATETIME NULL,
    notes TEXT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_license_key (license_key),
    KEY idx_license_module (module_id),
    KEY idx_license_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS license_devices (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    license_id BIGINT UNSIGNED NOT NULL,
    device_id VARCHAR(128) NOT NULL,
    device_name VARCHAR(190) NULL,
    platform VARCHAR(32) NULL,
    app_version VARCHAR(32) NULL,
    first_seen_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    last_seen_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    last_ip VARCHAR(45) NULL,
    country VARCHAR(2) NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_ld (license_id, device_id),
    CONSTRAINT fk_ld_lic FOREIGN KEY (license_id) REFERENCES licenses(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- API KEYS (for APK <-> panel auth)
-- ============================================================
CREATE TABLE IF NOT EXISTS api_keys (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    key_prefix VARCHAR(16) NOT NULL,
    key_hash VARCHAR(128) NOT NULL,
    secret_hash VARCHAR(128) NOT NULL,        -- HMAC secret (hashed)
    label VARCHAR(190) NOT NULL,
    module_id VARCHAR(64) NULL,
    scopes VARCHAR(500) NOT NULL DEFAULT '*',
    status ENUM('active','revoked') NOT NULL DEFAULT 'active',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    expires_at DATETIME NULL,
    last_used_at DATETIME NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_ak_prefix (key_prefix),
    KEY idx_ak_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- SETTINGS (global)
-- ============================================================
CREATE TABLE IF NOT EXISTS settings (
    setting_key VARCHAR(128) NOT NULL,
    setting_value LONGTEXT NULL,
    is_public TINYINT(1) NOT NULL DEFAULT 0,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (setting_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- AUDIT LOG
-- ============================================================
CREATE TABLE IF NOT EXISTS audit_log (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id BIGINT UNSIGNED NULL,
    actor VARCHAR(190) NULL,
    action VARCHAR(128) NOT NULL,
    subject_type VARCHAR(64) NULL,
    subject_id VARCHAR(128) NULL,
    module_id VARCHAR(64) NULL,
    ip_address VARCHAR(45) NULL,
    user_agent VARCHAR(500) NULL,
    meta JSON NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_audit_user (user_id),
    KEY idx_audit_action (action),
    KEY idx_audit_subject (subject_type, subject_id),
    KEY idx_audit_module (module_id),
    KEY idx_audit_time (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- NOTIFICATIONS
-- ============================================================
CREATE TABLE IF NOT EXISTS notifications (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id BIGINT UNSIGNED NULL,              -- NULL = broadcast
    level ENUM('info','success','warning','error') NOT NULL DEFAULT 'info',
    title VARCHAR(190) NOT NULL,
    body TEXT NULL,
    link VARCHAR(500) NULL,
    read_at DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_notif_user (user_id),
    KEY idx_notif_read (read_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- FILES (uploads registry)
-- ============================================================
CREATE TABLE IF NOT EXISTS files (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    module_id VARCHAR(64) NULL,
    owner_user_id BIGINT UNSIGNED NULL,
    kind ENUM('apk','ovpn','image','logo','background','doc','other') NOT NULL DEFAULT 'other',
    original_name VARCHAR(255) NOT NULL,
    stored_path VARCHAR(500) NOT NULL,
    mime VARCHAR(128) NULL,
    size_bytes BIGINT UNSIGNED NOT NULL DEFAULT 0,
    sha256 CHAR(64) NULL,
    public TINYINT(1) NOT NULL DEFAULT 0,
    meta JSON NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_files_module (module_id),
    KEY idx_files_kind (kind),
    KEY idx_files_sha (sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- DEVICES (app installs tracked)
-- ============================================================
CREATE TABLE IF NOT EXISTS devices (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    device_id VARCHAR(128) NOT NULL,
    module_id VARCHAR(64) NOT NULL,
    license_id BIGINT UNSIGNED NULL,
    platform VARCHAR(32) NULL,
    model VARCHAR(128) NULL,
    os_version VARCHAR(64) NULL,
    app_version VARCHAR(32) NULL,
    fcm_token VARCHAR(255) NULL,
    mqtt_client_id VARCHAR(128) NULL,
    country VARCHAR(2) NULL,
    last_ip VARCHAR(45) NULL,
    first_seen_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    last_seen_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_devices (device_id, module_id),
    KEY idx_devices_module (module_id),
    KEY idx_devices_license (license_id),
    KEY idx_devices_last_seen (last_seen_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- MESSAGES / ANNOUNCEMENTS
-- ============================================================
CREATE TABLE IF NOT EXISTS announcements (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    module_id VARCHAR(64) NULL,
    title VARCHAR(190) NOT NULL,
    body MEDIUMTEXT NOT NULL,
    target_country VARCHAR(10) NULL,
    target_version VARCHAR(32) NULL,
    starts_at DATETIME NULL,
    ends_at DATETIME NULL,
    enabled TINYINT(1) NOT NULL DEFAULT 1,
    created_by BIGINT UNSIGNED NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_ann_module (module_id),
    KEY idx_ann_enabled (enabled)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- COMMAND CENTER
-- ============================================================
CREATE TABLE IF NOT EXISTS device_commands (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    module_id VARCHAR(64) NOT NULL,
    target_device_id VARCHAR(128) NULL,       -- NULL = broadcast to module
    command VARCHAR(64) NOT NULL,             -- reboot, clear_cache, force_update, msg, ...
    payload JSON NULL,
    status ENUM('queued','sent','ack','failed') NOT NULL DEFAULT 'queued',
    issued_by BIGINT UNSIGNED NULL,
    issued_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    ack_at DATETIME NULL,
    PRIMARY KEY (id),
    KEY idx_cmd_module (module_id),
    KEY idx_cmd_target (target_device_id),
    KEY idx_cmd_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- SEEDS (default roles + permissions)
-- ============================================================
INSERT INTO roles (id, slug, name, is_system) VALUES
    (1, 'superadmin', 'Super Admin', 1),
    (2, 'admin',      'Admin',       1),
    (3, 'operator',   'Operator',    1),
    (4, 'viewer',     'Viewer',      1)
ON DUPLICATE KEY UPDATE name=VALUES(name);

INSERT INTO settings (setting_key, setting_value, is_public) VALUES
    ('panel.name',     'X1 Apps Central Panel', 1),
    ('panel.version',  '1.0.0',                 1),
    ('panel.brand',    'X1',                    1),
    ('panel.theme',    'dark',                  1)
ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value);
