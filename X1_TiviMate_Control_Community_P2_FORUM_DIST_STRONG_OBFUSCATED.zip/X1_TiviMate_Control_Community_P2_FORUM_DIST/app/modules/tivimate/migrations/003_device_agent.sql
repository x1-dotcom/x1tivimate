-- X1 TiviMate Control Community — Device Agent foundation.
-- Canonical device authority remains the existing `devices` table and command
-- authority remains `device_commands`. This schema is intentionally compatible
-- with the Commercial Control Plane upgrade path.

CREATE TABLE IF NOT EXISTS tivimate_enrollment_codes (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    code_hash CHAR(64) NOT NULL,
    expected_device_id VARCHAR(128) NULL,
    created_by BIGINT UNSIGNED NULL,
    expires_at DATETIME NOT NULL,
    used_at DATETIME NULL,
    used_device_pk BIGINT UNSIGNED NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_tivimate_enrollment_hash (code_hash),
    KEY idx_tivimate_enrollment_expiry (expires_at),
    KEY idx_tivimate_enrollment_device (used_device_pk),
    CONSTRAINT fk_tivimate_enrollment_user FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL,
    CONSTRAINT fk_tivimate_enrollment_device FOREIGN KEY (used_device_pk) REFERENCES devices(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS tivimate_device_tokens (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    device_pk BIGINT UNSIGNED NOT NULL,
    token_hash CHAR(64) NOT NULL,
    status ENUM('active','revoked') NOT NULL DEFAULT 'active',
    issued_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    last_used_at DATETIME NULL,
    revoked_at DATETIME NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_tivimate_token_hash (token_hash),
    KEY idx_tivimate_token_device (device_pk),
    CONSTRAINT fk_tivimate_token_device FOREIGN KEY (device_pk) REFERENCES devices(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS tivimate_device_capabilities (
    device_pk BIGINT UNSIGNED NOT NULL,
    capability VARCHAR(64) NOT NULL,
    enabled TINYINT(1) NOT NULL DEFAULT 1,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (device_pk, capability),
    KEY idx_tivimate_capability (capability, enabled),
    CONSTRAINT fk_tivimate_cap_device FOREIGN KEY (device_pk) REFERENCES devices(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS tivimate_heartbeats (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    device_pk BIGINT UNSIGNED NOT NULL,
    app_version VARCHAR(32) NULL,
    app_version_code BIGINT NULL,
    os_version VARCHAR(64) NULL,
    manufacturer VARCHAR(128) NULL,
    model VARCHAR(128) NULL,
    network_type VARCHAR(32) NULL,
    vpn_state VARCHAR(32) NULL,
    storage_free_mb BIGINT NULL,
    memory_free_mb BIGINT NULL,
    body_sha256 CHAR(64) NOT NULL,
    telemetry_json JSON NULL,
    received_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_tivimate_hb_device_time (device_pk, received_at),
    CONSTRAINT fk_tivimate_hb_device FOREIGN KEY (device_pk) REFERENCES devices(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS tivimate_request_nonces (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    token_id BIGINT UNSIGNED NOT NULL,
    nonce VARCHAR(96) NOT NULL,
    request_ts BIGINT NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_tivimate_token_nonce (token_id, nonce),
    KEY idx_tivimate_nonce_created (created_at),
    CONSTRAINT fk_tivimate_nonce_token FOREIGN KEY (token_id) REFERENCES tivimate_device_tokens(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE device_commands
    MODIFY COLUMN status ENUM('queued','sent','ack','delivered','acknowledged','completed','failed','expired') NOT NULL DEFAULT 'queued',
    ADD COLUMN IF NOT EXISTS capability VARCHAR(64) NULL AFTER command,
    ADD COLUMN IF NOT EXISTS payload_hash CHAR(64) NULL AFTER payload,
    ADD COLUMN IF NOT EXISTS delivered_at DATETIME NULL AFTER issued_at,
    ADD COLUMN IF NOT EXISTS completed_at DATETIME NULL AFTER ack_at,
    ADD COLUMN IF NOT EXISTS failed_at DATETIME NULL AFTER completed_at,
    ADD COLUMN IF NOT EXISTS expires_at DATETIME NULL AFTER failed_at,
    ADD COLUMN IF NOT EXISTS progress TINYINT UNSIGNED NULL AFTER expires_at,
    ADD COLUMN IF NOT EXISTS result_json JSON NULL AFTER progress,
    ADD KEY IF NOT EXISTS idx_cmd_capability (module_id, capability),
    ADD KEY IF NOT EXISTS idx_cmd_expiry (status, expires_at);

CREATE TABLE IF NOT EXISTS tivimate_command_results (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    command_id BIGINT UNSIGNED NOT NULL,
    device_pk BIGINT UNSIGNED NOT NULL,
    state ENUM('delivered','acknowledged','completed','failed','expired') NOT NULL,
    progress TINYINT UNSIGNED NULL,
    result_json JSON NULL,
    error_code VARCHAR(128) NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_tivimate_result_command (command_id, created_at),
    KEY idx_tivimate_result_device (device_pk, created_at),
    CONSTRAINT fk_tivimate_result_command FOREIGN KEY (command_id) REFERENCES device_commands(id) ON DELETE CASCADE,
    CONSTRAINT fk_tivimate_result_device FOREIGN KEY (device_pk) REFERENCES devices(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
