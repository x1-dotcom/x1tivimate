-- APK error/crash reports + Telegram notification settings.

CREATE TABLE IF NOT EXISTS error_reports (
    id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    module_id   VARCHAR(64)     NOT NULL,
    license_id  BIGINT UNSIGNED NULL,
    device_id   VARCHAR(190)    NULL,
    level       ENUM('debug','info','warning','error','fatal') NOT NULL DEFAULT 'error',
    subject     VARCHAR(255)    NOT NULL,
    body        LONGTEXT        NULL,
    meta        LONGTEXT        NULL,
    app_version VARCHAR(64)     NULL,
    platform    VARCHAR(32)     NULL,
    status      ENUM('open','acknowledged','closed') NOT NULL DEFAULT 'open',
    ip          VARCHAR(45)     NULL,
    telegram_sent TINYINT(1)    NOT NULL DEFAULT 0,
    created_at  DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at  DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_reports_module    (module_id, created_at),
    KEY idx_reports_status    (status, created_at),
    KEY idx_reports_license   (license_id),
    KEY idx_reports_level     (level)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Telegram outbound notification settings
INSERT INTO settings (setting_key, setting_value, is_public) VALUES
    ('telegram.enabled',   '0', 0),
    ('telegram.bot_token', '',  0),
    ('telegram.chat_id',   '',  0),
    ('telegram.min_level', 'error', 0)
ON DUPLICATE KEY UPDATE setting_key = setting_key;
