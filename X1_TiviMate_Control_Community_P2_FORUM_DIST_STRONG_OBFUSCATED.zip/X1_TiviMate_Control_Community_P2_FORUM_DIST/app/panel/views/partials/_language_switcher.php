<?php
use X1\Core\Services\I18n\LocaleService;
$x1CurrentLocale = LocaleService::detect();
$x1Locales = LocaleService::supported();
?>
<div class="x1-language-switcher" data-x1-language-switcher>
  <label class="x1-lang-label" for="x1-locale-select">
    <i class="bi bi-translate"></i>
    <span data-i18n="x1.language">Idioma</span>
  </label>
  <select id="x1-locale-select" class="form-select form-select-sm x1-lang-select" data-x1-locale-select aria-label="Language selector">
    <?php foreach ($x1Locales as $code => $label): ?>
      <option value="<?= e($code) ?>" <?= $code === $x1CurrentLocale ? 'selected' : '' ?>><?= e($label) ?></option>
    <?php endforeach; ?>
  </select>
</div>
<style>
.x1-language-switcher{display:inline-flex;align-items:center;gap:.45rem;padding:.28rem .42rem;border:1px solid rgba(148,163,184,.22);background:rgba(15,23,42,.68);border-radius:999px;box-shadow:0 14px 35px rgba(0,0,0,.18);backdrop-filter:blur(14px);color:#dbeafe;white-space:nowrap}
.x1-language-switcher .x1-lang-label{display:inline-flex;align-items:center;gap:.35rem;margin:0;font-size:.75rem;color:#93c5fd;letter-spacing:.02em;text-transform:uppercase}
.x1-language-switcher .x1-lang-select{width:auto;min-width:7.8rem;border:0;background:rgba(2,6,23,.45);color:#f8fafc;border-radius:999px;font-size:.78rem;padding:.22rem 1.85rem .22rem .7rem}
.x1-language-switcher .x1-lang-select:focus{box-shadow:0 0 0 .16rem rgba(34,211,238,.22)}
body.x1-login-v2 .x1-language-switcher{position:fixed;top:1rem;right:1rem;z-index:60}
@media (max-width: 700px){.x1-language-switcher .x1-lang-label span{display:none}.x1-language-switcher .x1-lang-select{min-width:6.8rem}}
</style>
