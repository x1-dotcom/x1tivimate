<?php
declare(strict_types=1);

$root = realpath($argv[1] ?? (__DIR__ . '/../app'));
if (!$root || !is_dir($root)) { fwrite(STDERR,"app root missing\n"); exit(2); }
$errors=[];
$blockedNames=['.env','panel.pass','secrets.json'];
$blockedExt=['jks','p12','pfx','pem','key','keystore','db','sqlite','sqlite3','apk'];
$it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root,FilesystemIterator::SKIP_DOTS));
foreach($it as $p=>$f){
    if(!$f->isFile()) continue;
    $name=$f->getFilename(); $ext=strtolower($f->getExtension());
    if(in_array($name,$blockedNames,true)||in_array($ext,$blockedExt,true)) $errors[]='blocked material: '.substr($p,strlen($root)+1);
    if(str_contains($name,'.bak')||str_ends_with($name,'~')||in_array($ext,['old','orig'],true)) $errors[]='backup residue: '.substr($p,strlen($root)+1);
}
$mods=[];
$modDir=$root.'/modules';
if(is_dir($modDir)) foreach(scandir($modDir)?:[] as $n){if($n!=='.'&&$n!=='..'&&is_dir($modDir.'/'.$n))$mods[]=$n;}
sort($mods);
if($mods!==['tivimate']) $errors[]='community modules must be only tivimate';
$manifest=json_decode((string)@file_get_contents($root.'/modules/tivimate/module.json'),true);
if(!is_array($manifest)||($manifest['license_required']??null)!==false) $errors[]='TiviMate must be license-free';
if(($manifest['package']??'')!=='ar.tvplayer.tv') $errors[]='package mismatch';

require $root.'/core/.x1rt.php';
require $root.'/core/Autoloader.php';
\X1Autoloader::register($root);
$classes=[
 'X1\\Core\\Router','X1\\Core\\Auth','X1\\Core\\Database',
 'X1\\Panel\\Controllers\\AuthController',
 'X1\\Modules\\Tivimate\\Api\\CommunityApi','X1\\Modules\\Tivimate\\Api\\AgentApi',
 'X1\\Modules\\Tivimate\\Controllers\\AgentController'
];
foreach($classes as $c) if(!class_exists($c)) $errors[]='protected class failed to load: '.$c;

if(class_exists('X1\\Modules\\Tivimate\\Api\\AgentApi')){
    $rc=new ReflectionClass('X1\\Modules\\Tivimate\\Api\\AgentApi');
    $cc=$rc->getReflectionConstant('SAFE_CAPABILITIES');
    $caps=$cc?$cc->getValue():null;
    $expected=['sync_config','show_message','check_update'];
    if($caps!==$expected) $errors[]='Community capability boundary mismatch';
}

if(class_exists('X1\\Core\\Router')){
    $router=new \X1\Core\Router();
    require $root.'/panel/routes_community.php';
    $rr=new ReflectionClass($router); $rp=$rr->getProperty('routes'); $routes=$rp->getValue($router);
    $patterns=[];
    foreach($routes as $method=>$items) foreach($items as $r) $patterns[]=(string)($r['pattern']??'');
    if(!in_array('/Gizmos_RC11/api/reseller/tivimate/api.php',$patterns,true)) $errors[]='legacy supplied-APK route missing';
    foreach(['/admin/saas','/admin/resellers','/admin/licenses','/admin/apk','/customer/store'] as $bad){
        foreach($patterns as $p) if(str_starts_with($p,$bad)) $errors[]='commercial route exposed: '.$p;
    }
}

$login=(string)@file_get_contents($root.'/panel/views/auth/login.php');
$community=(string)@file_get_contents($root.'/config/community.php'); // protected payload is intentionally opaque
foreach(['https://t.me/+XkuQS_QuD6g4Nzc0','https://forum.x1panel.space','https://discord.gg/vSSw6jHmw'] as $url){
    if(!str_contains($login,$url) && !str_contains($community,$url)) $errors[]='official link missing from presentation/config: '.$url;
}
if(!str_contains($login,"date('Y')")) $errors[]='dynamic copyright year missing';
if(!is_file($root.'/public/assets/img/x1-community-brand.jpg')) $errors[]='brand image missing';

// Strong-build proof: high-value files must be wrappers, not readable source.
foreach([
 'core/Auth.php','core/Router.php','panel/routes_community.php',
 'modules/tivimate/Api/CommunityApi.php','modules/tivimate/Api/AgentApi.php'
] as $rel){
    $t=(string)@file_get_contents($root.'/'.$rel);
    if($t===''||!str_contains($t,'return eval(')) $errors[]='protected wrapper missing: '.$rel;
    foreach(['function enroll','final class AgentApi','SELECT * FROM users','SAFE_CAPABILITIES'] as $needle){
        if(str_contains($t,$needle)) $errors[]='readable internal marker leaked in '.$rel.': '.$needle;
    }
}

if($errors){echo "X1 COMMUNITY PROTECTED RELEASE: FAIL\n";foreach($errors as $e) echo " - $e\n";exit(2);}
echo "X1 COMMUNITY PROTECTED RELEASE: PASS\n";
echo "modules: tivimate\npackage: ar.tvplayer.tv\ncapabilities: sync_config, show_message, check_update\nprotected runtime: OK\n";
