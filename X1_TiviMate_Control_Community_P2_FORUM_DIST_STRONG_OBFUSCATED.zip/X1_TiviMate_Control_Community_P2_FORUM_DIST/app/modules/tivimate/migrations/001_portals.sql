-- X1 TiviMate Control Community — portal registry.
CREATE TABLE IF NOT EXISTS tivimate_services (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    name VARCHAR(191) NOT NULL DEFAULT '',
    url VARCHAR(500) NOT NULL DEFAULT '',
    type ENUM('xtream','stalker','m3u8') NOT NULL DEFAULT 'xtream',
    code VARCHAR(64) NOT NULL DEFAULT '',
    position INT UNSIGNED NOT NULL DEFAULT 0,
    enabled TINYINT(1) NOT NULL DEFAULT 1,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_tivimate_services_position (position),
    KEY idx_tivimate_services_enabled (enabled)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Upgrade path for an Apps Central database that already has the historical table.
ALTER TABLE tivimate_services
    ADD COLUMN IF NOT EXISTS type ENUM('xtream','stalker','m3u8') NOT NULL DEFAULT 'xtream' AFTER url,
    ADD KEY IF NOT EXISTS idx_tivimate_services_enabled (enabled);
