-- Dynamic IP banlist populated by BotShield middleware (honeypot hits, UA matches,
-- repeated 4xx). TTL-based: rows past expires_at are ignored, housekeep prunes them.

CREATE TABLE IF NOT EXISTS ip_bans (
    ip_address  VARCHAR(45) NOT NULL PRIMARY KEY,
    reason      VARCHAR(64) NOT NULL,
    hits        INT UNSIGNED NOT NULL DEFAULT 1,
    first_seen  DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    last_seen   DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    expires_at  DATETIME    NOT NULL,
    KEY idx_ipban_expires (expires_at),
    KEY idx_ipban_reason  (reason)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
