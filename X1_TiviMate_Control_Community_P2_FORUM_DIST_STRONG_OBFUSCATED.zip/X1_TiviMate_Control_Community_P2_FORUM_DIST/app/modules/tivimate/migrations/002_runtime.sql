-- X1 TiviMate Control Community — runtime support.
CREATE TABLE IF NOT EXISTS tivimate_qr_sessions (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    pair_hash CHAR(64) NOT NULL,
    device_hash CHAR(64) NOT NULL,
    short_code VARCHAR(12) NOT NULL,
    status ENUM('waiting','complete','consumed','expired') NOT NULL DEFAULT 'waiting',
    payload_enc LONGTEXT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    expires_at DATETIME NOT NULL,
    consumed_at DATETIME NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_tivimate_pair_hash (pair_hash),
    UNIQUE KEY uq_tivimate_device_hash (device_hash),
    KEY idx_tivimate_pair_code (short_code),
    KEY idx_tivimate_pair_status (status, expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO module_settings (module_id, setting_key, setting_value) VALUES
 ('tivimate','community.enabled','1'),
 ('tivimate','api_mode','original_panel'),
 ('tivimate','welcome_title','Welcome'),
 ('tivimate','welcome_body','Select your portal and sign in.'),
 ('tivimate','welcome_footer','Powered by X1'),
 ('tivimate','intro_url',''),
 ('tivimate','streaming_enabled','0'),
 ('tivimate','streaming_package',''),
 ('tivimate','webview_enabled','0'),
 ('tivimate','webview_url',''),
 ('tivimate','sports_enabled','0'),
 ('tivimate','sports_url',''),
 ('tivimate','vpn_profiles_json','[]')
ON DUPLICATE KEY UPDATE setting_value = setting_value;
